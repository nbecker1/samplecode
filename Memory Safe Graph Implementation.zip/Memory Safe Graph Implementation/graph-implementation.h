/*A graph has a parameter which points to the head vertex of a linked list of 
vertices. Each vertex has a name and a pointer to its first edge. Each edge
points to the next edge that stems from the vertex. Each edge also has a 
pointer to the vertex that it points to*/
#if !defined(graph_implementation_h)
#define graph_implementation_h
struct edge;
typedef struct vertex {
    char *name;
    struct vertex *next;
    struct edge *head;
} Vertex;

typedef struct edge {
    int cost;
    Vertex *pointsto;
    struct edge *next;
} Edge;

typedef struct graph {
	Vertex *head;
} Graph;
#endif
