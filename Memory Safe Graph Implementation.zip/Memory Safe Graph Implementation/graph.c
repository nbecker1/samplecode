/*Noah Becker
CMSC 216
Larry Herman
Section 0102

This program is designed to perform operations on a graph structure, which
is defined in the header file graph-implementation.h. Functions in this file
initialize the graph, add vertices and edges to it, calculate the number of
vertices in it, determine whether or not specific vertices exist, return the
cost of a specified edge, change the cost of a specified edge and return the
number of neighbors a specific vertex has. 
*/
#include "graph.h"
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


/*this function initializes a graph, given that the pointer parameter is not
null*/
void init_graph(Graph *graph) {
	if (graph != NULL)
		graph->head = NULL;
}

/*This function adds a vertex with the name new_vertex to the Graph graph.
It returns 1 upon success and 0 upon failure. Failures occur when there are
NULL parameters or there already exists a vertex with name new_vertex*/
int add_vertex(Graph *graph, const char new_vertex[]) {
	
	Vertex *new = NULL, *cur, *prev = NULL;	

	/*Checks for NULL parameters*/
	if (new_vertex == NULL || graph == NULL)
		return 0;

	/*initializes cur to the first element of the linked list of vertices*/
	cur = graph->head;

	/*Checks if there is already a vertex with name new_vertex in the graph,
	returns 0 if there is, and if not, stores the last vertex in the list in
	prev.*/
	while (cur != NULL && strcmp(cur->name, new_vertex) < 0) {
		prev = cur;
		cur = cur->next;
	}

	if (cur != NULL && strcmp(cur->name, new_vertex) == 0)
		return 0;

	/*Allocating memory for the new Vertex*/
	new = malloc(sizeof(Vertex));

	/*Checking if malloc was successful, and exiting if not*/
	if (new == NULL) {
		printf("Memory Allocation was unsuccessful. Program Exiting ...");
		exit(1);
	}
	/*Allocating memory for the new Vertex's name*/
	new->name = malloc(sizeof(char)*strlen(new_vertex) + 1);

	/*Checking if malloc was successful, and exiting if not*/
	if (new->name == NULL) {
		printf("Memory Allocation was unsuccessful. Program Exiting ...");
		exit(1);
	}
	/*Initializes other Vertex variables to NULL since the new Vertex will
	always be the last in the list*/
	new->next = cur;
	new->head = NULL;

	/*Makes a copy of the name and puts it in the new Vertex. The copy is
	made so that if a user calls free on the name passed in, the data is not
	lost from the graph*/
	strcpy(new->name,new_vertex);

	/*0 element list; makes new the head node*/
	if (prev == NULL)
		graph->head = new;
	/*otherwise, the last elements next variable is set to the new Vertex*/
	else
		prev->next = new;
	/*Returns 1 because all failure conditions have already been checked above*/
	return 1;
}
	
/*this function returns the number of vertices in the specified graph*/
int num_vertices(Graph graph) {
	Vertex *cur;
	int counter = 0;

	/*Iterates through the linked list of vertices and counts them*/
	cur = graph.head;
	while (cur != NULL) {
		counter++;
		cur = cur->next;
	}

	return counter;
}

/*This function returns 1 if the graph has the vertex with name name, and 
0 in failure conditions or otherwise. There is only one failure condition
for this function, which a NULL parameter*/
int has_vertex(Graph graph, const char name[]) {
	Vertex *cur = graph.head;

	/*Checks for failure condition*/
	if (name == NULL)
		return 0;

	/*iterates through the linked list of vertices and if it finds one with
	the name name, returns 1, otherwise returns 0 after cycling through the 
	whole list*/
	while (cur != NULL) {
		if (strcmp(name, cur->name) == 0) {
			return 1;
		}
		cur = cur->next;
	}
	return 0;
}

/*This function adds ad edge to the graph and returns 1 if successful and 0
otherwise. This function would be unsuccessful if it receives NULL parameters,
source or dest are not in the graph or the cost parameter is less than 0,
because costs may not be negative.*/
int add_edge(Graph *graph, const char source[], const char dest[], int cost) {
	Edge *new, *curEdge, *prevEdge = NULL;
	Vertex *src = NULL, *d = NULL, *cur;
	
	/*Checks if cost is less than 0 or the parameters are NULL*/
	if (cost < 0 || source == NULL || dest == NULL || graph == NULL)
		return 0;

	/*Once it is determined that graph is not NULL, cur is initialized*/
	cur = graph->head;

	/*Cycles through the linked list of vertices and if it finds sourcce or
	dest, assigns cur to a separate pointer so that it may be accessed 
	later*/
	while (cur != NULL) {
		if (strcmp(cur->name, source) == 0)
			src = cur;
		if (strcmp(cur->name, dest) == 0)
			d = cur;
		cur = cur->next;
	}

	/*Checks if src and d are still NULL. If one is, it means that it is not
	in the graph, so 0 is returned*/
	if (src == NULL || d == NULL)
		return 0;

	/*At this point, it is known that src is not NULL so curEdge may be set
	to the head node of the linked list of edges stemming from src*/
	curEdge = src->head;

	/*Iterates through the linked list of edges stemming from src. if the list
	is nonempty, the last element is stored in prevEdge.*/
	while (curEdge != NULL && strcmp(curEdge->pointsto->name, dest) < 0) {
		prevEdge = curEdge;
		curEdge = curEdge->next;
	}

	if (curEdge != NULL && strcmp(curEdge->pointsto->name, dest) == 0)
		return 0;

	/*Allocates memory for the new Edge*/
	new = malloc(sizeof(Edge));

	/*Checking if malloc was successful, and exiting if not*/
	if (new == NULL) {
		printf("Memory Allocation was unsuccessful. Program Exiting ...");
		exit(1);
	}
	/*Initializes next to be NULL since the edge will be added to the end of
	the linked list.*/
	new->next = curEdge;
	new->cost = cost;
	/*sets the vertex to which the edge points to be the desination vertex
	found in the first loop in this function*/
	new->pointsto = d;

	/*Empty list case; sets the head of the list to be the new edge*/
	if (prevEdge == NULL)
		src->head = new;
	/*otherwise; sets the next element of the last element of the list to the
	new edge*/
	else
		prevEdge->next = new;
	/*returns 1, because all failure cases have already been checked above*/
	return 1;


}

/*This function returns the cost of the edge in graph from source to dest, 
as long as the edge exists in the graph. The function returns -1 if it fails
for any reason. The function could fail if any of the parameters*/
int get_edge_cost(Graph graph, const char source[], const char dest[]) {
	Vertex *src = NULL, *d = NULL, *cur = graph.head;
	Edge *curEdge;

	/*Checks for NULL parameters*/
	if (source == NULL || dest == NULL)
		return -1;

	/*Iterates through linked list of vertices and if it finds source or dest,
	stores them in src and d respectively, for later use.*/
	while (cur != NULL) {
		if (strcmp(cur->name, source) == 0)
			src = cur;
		if (strcmp(cur->name, dest) == 0)
			d = cur;
		cur = cur->next;
	}

	/*If either src or d are still NULL, then they don't exist in the graph,
	and -1 is returned*/
	if (src == NULL || d == NULL)
		return -1;

	/*At this point it is known that src is not NULL, so curEdge gets the 
	value of the head node stored in src to begin iterating thorugh the 
	linked list of edges stemming from src*/
	curEdge = src->head;

	/*Iterates through the list, and if an edge that points to dest is found,
	it's cost is returned*/
	while (curEdge != NULL) {
		if (strcmp(curEdge->pointsto->name, dest) == 0)
			return curEdge->cost;
		curEdge = curEdge->next;
	}
	/*If no edge from source to dest is found, execution reaches this 
	statement and -1 is returned*/
	return -1;
}

/*This function changes the cost of the edge in the graph from source to dest
and if successful, returns 1. Returns 0 otherwise. The function might not 
succeed if the parameters are NULL, source or dest are not in the graph, 
there is no edge from source to dest or the new_cost is negative.*/
int change_edge_cost(Graph *graph, const char source[], const char dest[],
                     int new_cost) {
	Vertex *src = NULL, *d = NULL, *cur;
	Edge *curEdge;

	/*Checks the validity of parameters*/
	if (new_cost < 0 || source == NULL || dest == NULL || graph == NULL)
		return 0;

	/*knowing that graph is not NULL, initializes cur to the head node of 
	the linked list of vertices*/
	cur = graph->head;

	/*Iterates through the linked list of vertices and if it finds source or
	dest, stores the vertex into src or d respectively, for later use*/
	while (cur != NULL) {
		if (strcmp(cur->name, source) == 0)
			src = cur;
		if (strcmp(cur->name, dest) == 0)
			d = cur;
		cur = cur->next;
	}

	/*If src or d are still NULL then source or dest is not in the graph, so
	0 is returned*/
	if(src == NULL || d == NULL)
		return 0;

	/*Initializing curEdge so that it may iterate through the linked list of 
	edges stemming from src*/
	curEdge = src->head;

	/*If the edge is found, then its cost is changed and 1 is returned*/
	while (curEdge != NULL) {
		if (strcmp(curEdge->pointsto->name, dest) == 0) {
			curEdge->cost = new_cost;
			return 1;
		}
		curEdge = curEdge->next;
	}
	/*If execution reaches this point, the edge is not in the graph, so 0 is
	 returned*/
	return 0;

}

/*This function returns the number of edges stemming from the Vertex vertex
in the Graph graph. It fails and returns -1 if vertex is NULL or it is not
in the graph*/
int num_neighbors(Graph graph, const char vertex[]) {

	Vertex *src = NULL, *cur = graph.head;
	Edge *curEdge;
	int count = 0;

	/*Checks if vertex is NULL, and returns 1 if so*/
	if (vertex == NULL)
		return -1;

	/*Iterates through the linked list of vertices and if it finds vertex,
	stores it in src. Once src is found, loop is terminated by setting cur
	to NULL*/
	while (cur != NULL) {
		if (strcmp(cur->name, vertex) == 0) {
			src = cur;
			cur = NULL;
		}
		else
			cur = cur->next;
	}

	/*If src was not found by the while loop, it is not in the graph, return
	 -1*/
	if (src == NULL)
		return -1;

	/*By this point, it is known that src is not NULL so curEdge is 
	initialized to the first element of the linked list of edges 
	stemming from src*/
	curEdge = src->head;

	/*Iterates through the linked list of edges, counting them*/
	while (curEdge != NULL) {
		count++;
		curEdge = curEdge->next;
	}

	/*returns number of edges stemming from src(vertex)*/
	return count;
}

/*This function takes a pointer to a graph and clears the graph of all 
vertices and edges and properly frees the memory allocated for the graph*/
void clear_graph(Graph *graph) {
	Vertex *cur, *prev;
	Edge *curEdge, *prevEdge;
	Graph newGraph;

	/*Checks parameter for NULL*/
	if (graph != NULL) {
		/*It is now safe to access graph->head*/
		cur = graph->head;
		/*Cycles through vertices and frees their allocated memory*/
		while (cur != NULL) {
			prev = cur;
			cur = cur->next;
			/*Cycles through edges of the current vertex 
			and frees their memory*/
			curEdge = prev->head;
			while (curEdge !=NULL) {
				prevEdge = curEdge;
				curEdge = curEdge->next;
				free(prevEdge);
			} 
			free(prev->name);
			free(prev);
		}
		/*sets the parameter to an  new, uninitialized graph*/
		*graph = newGraph;
	}
}

/*This function takes a graph and returns an alphabetically ordered list of 
the vertices in it.*/
char **get_vertices(Graph graph) {
	Vertex *cur = graph.head;
	int num = num_vertices(graph), count = 0;
	char **arr;
	/*allocate memory for the array of names*/
	arr = malloc((num + 1) * sizeof(char *));

	/*Checks for memory allocation failure and prints error message and exits 
	program unsuccessfully*/
	if (arr == NULL) {
		printf("Memory Allocation was unsuccessful. Program Exiting ...");
		exit(1);
	}

	/*Cycles through vertices which were ordered alphabetically as they 
	were inserted and copies them to the array to be returned*/
	while (cur != NULL) {
		/*Allocates memory for each element of the array*/
		arr[count] = malloc(strlen(cur->name) + 1);

		/*Checks for meory allocation failure*/
		if (arr[count] == NULL) {
			printf("Memory Allocation was unsuccessful. Program Exiting ...");
			exit(1);
		}
		/*Copies the vertex name into the next array element*/
		strcpy(arr[count], cur->name);
		count++;
		cur = cur->next;
	}
	/*The list is terminated with a NULL pointer*/
	arr[num] = NULL;
	return arr;
}
/*This function takes a graph and returns an alphabetically ordered list of
edges stemming from the parameter vertex*/
char **get_neighbors(Graph graph, const char vertex[]) {
	Vertex *cur = graph.head;
	Edge *curEdge;
	char **arr;
	int num = num_neighbors(graph, vertex), count = 0;;

	/*Checks if vertex is NULL or if it is not in the graph by using error 
	checks from num_neighbors*/
	if (num < 0 /*|| vertex == NULL*/) 
		return NULL;


	/*allocate memory for the list*/
	arr = malloc((num + 1) * sizeof(char *));

	/*Checks if memory allocation succeeded*/
	if (arr == NULL) {
		printf("Memory Allocation was unsuccessful. Program Exiting ...");
		exit(1);
	}
	
	/*Cycle through vertices to find vertex*/
	while (cur != NULL && strcmp(cur->name, vertex) < 0) {
		cur = cur->next;
	}

	curEdge = cur->head;

	/*Cycles through edges that stem from vertex and copies their destination
	names into the list to be returned*/
	while (curEdge != NULL) {
		/*Allocates for each element of the list*/
		arr[count] = malloc(strlen(curEdge->pointsto->name) + 1);
		/*Checks for memory allocation failure*/
		if (arr[count] == NULL) {
			printf("Memory Allocation was unsuccessful. Program Exiting ...");
			exit(1);
		}
		/*Copies data to array*/
		strcpy(arr[count], curEdge->pointsto->name);
		count++;
		curEdge = curEdge->next;
	}
	/*The list is terminated with a NULL pointer*/
	arr[num] = NULL;
	return arr;
}

/*This method frees the memory of the list of vertices that a user may 
acquire by calling get_vertices*/
void free_vertex_name_list(char **vertex_names) {
	int count = 0;

	/*Checks for NULL parameter*/
	if (vertex_names != NULL) {
		/*Frees memory of each element of the list*/
		while (vertex_names[count] != NULL) {
			free (vertex_names[count]);
			count++;
		}
		/*Frees the pointer to the list*/
		free(vertex_names);
	}
}

/*Removes the edge from source to dest if it is present and the parameters
 are non NULL. If these conditions are met, 1 is returned, otherwise 0 is 
 returned*/
int remove_edge(Graph *graph, const char source[], const char dest[]) {
	Vertex *src = NULL, *d = NULL, *cur;
	Edge *curEdge, *prevEdge = NULL;

	/*NULL paramter check*/
	if (graph == NULL || source == NULL || dest == NULL)
		return 0;

	cur = graph->head;

	/*Cycles through vertices and stores the vertex with name source and the 
	name dest in the pointers src and d, respectively*/
	while (cur != NULL) {
		if (strcmp(cur->name, source) == 0)
			src = cur;
		if (strcmp(cur->name, dest) == 0)
			d = cur;
		cur = cur->next;
	}

	/*Checks if either source or dest are not in the graph*/
	if (src == NULL || d == NULL)
		return 0;

	curEdge = src->head;

	/*Cycles to the place in the list where the edge to dest would be if it 
	exists*/ 
	while (curEdge != NULL && strcmp(curEdge->pointsto->name, dest) < 0) {
		prevEdge = curEdge;
		curEdge = curEdge->next;
	}

	/*Checks if the edge is not there*/
	if (curEdge == NULL || (curEdge != NULL && 
			strcmp(curEdge->pointsto->name, dest) != 0))
		return 0;

	/*Case for removing the head node*/
	if (prevEdge == NULL)
		src->head = curEdge->next;
	/*Middle or end node case*/
	else 
		prevEdge->next = curEdge->next;
	/*Frees memory with removed edge*/
	free(curEdge);
	/*Returns success*/
	return 1;

}

/*This function removes the vertex vertex from the graph graph, given that 
it is in the graph and the paramters are non NULL. 1 is returned on success,
0 otherwise.*/
int remove_vertex(Graph *graph, const char vertex[]) {
	Vertex *cur, *toBeRemoved = NULL, *prev = NULL;
	Edge *curEdge, *prevEdge = NULL;

	/*NULL parameter check*/
	if (graph == NULL || vertex == NULL) 
		return 0;

	cur = graph->head;

	/*checks if vertex is the head node*/
	if (cur != NULL && strcmp(cur->name, vertex) == 0)
		toBeRemoved = cur;
		
	/*Cycles through vertices*/
	while (cur != NULL) {
		/*checks if the next node is vertex*/
		if (cur->next != NULL && strcmp(cur->next->name, vertex) == 0) {
			prev = cur;
			toBeRemoved = prev->next;
		}
		/*Removes all edges pointing to cur*/
		remove_edge(graph, cur->name, vertex);
		cur = cur->next;
	}

	/*If the vertex is not in the graph, return 0*/
	if (toBeRemoved == NULL)
		return 0;

	curEdge = toBeRemoved->head;
	/*Frees all of the edges stemming from vertex*/
	while (curEdge != NULL) {
		prevEdge = curEdge;
		curEdge = curEdge->next;
		free(prevEdge);
	}

	/*Checks if verte was the head vertex*/
	if (prev == NULL)
		graph->head = toBeRemoved->next;
	/*Middle of the list or end of the list*/
	else
		prev->next = toBeRemoved->next;
	/*Free vertex, icluding its name which is separately allocated*/
	free(toBeRemoved->name);
	free(toBeRemoved);
	/*Returns success condition*/
	return 1;
}