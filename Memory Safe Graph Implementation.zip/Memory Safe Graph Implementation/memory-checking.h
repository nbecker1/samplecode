void setup_memory_checking();
void check_heap();
