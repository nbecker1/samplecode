#if !defined(NAME_LIST_TO_STRING_H)
#define NAME_LIST_TO_STRING_H

/* an arbitrary length that we do not plan to exceed */
#define MAX_LEN 1000

void name_list_to_string(char **names, char result[]);

#endif
