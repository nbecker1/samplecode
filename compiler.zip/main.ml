open Ast
open Instr
open Disassembler

exception NoSuchClass
(*********************************************************************)

let rec output_expr o = function
  | EInt i -> Printf.fprintf o "%d" i
  | ENil -> Printf.fprintf o "nil"
  | ESelf -> Printf.fprintf o "self"
  | EString s -> Printf.fprintf o "\"%s\"" s
  | ELocRd x -> output_string o x
  | ELocWr (x, e) ->
      Printf.fprintf o "%s = (%a)" x output_expr e
  | EFldRd x -> output_string o x
  | EFldWr (x, e) ->
      Printf.fprintf o "%s = (%a)" x output_expr e
  | EIf (e1, e2, e3) ->
      Printf.fprintf o "if %a then %a else %a end" output_expr e1
	output_expr e2 output_expr e3
  | EWhile (e1, e2) ->
     Printf.fprintf o "while %a do %a end" output_expr e1 output_expr e2
  | ESeq (e1, e2) -> Printf.fprintf o "%a; %a" output_expr e1 output_expr e2
  | ENew x ->
      Printf.fprintf o "new %s" x
  | EInstanceOf (e, s) -> Printf.fprintf o "%a instanceof %s" output_expr e s 
  | EInvoke (e, m, es) ->
      Printf.fprintf o "%a.%s(%a)" output_expr e m output_exprs es

and output_exprs o = function
    [] -> ()
  | [e] -> output_expr o e
  | e::es -> Printf.fprintf o "%a, %a" output_expr e output_exprs es

and output_arg o = function
    s -> Printf.fprintf o "%s" s

and output_args o = function
  | [] -> ()
  | [a] -> output_arg o a
  | a::aa -> Printf.fprintf o "%a, %a" output_arg a output_args aa

and output_locals o = function
  | [] -> ()
  | [l] -> output_arg o l
  | l::ls -> Printf.fprintf o "%a\n%a" output_arg l output_locals ls

and output_meth o ({meth_name=name; meth_args=args; meth_body=body}:meth) =
  Printf.fprintf o "  def %s(%a)\n %a\n  end\n" name output_args args output_expr body

and output_meths o = function
    [] -> ()
  | [m] -> Printf.fprintf o "%a" output_meth m
  | m::ms -> Printf.fprintf o "%a\n%a" output_meth m output_meths ms

and output_cls o ({cls_name=name; cls_super=super; cls_meths=meths}:cls) =
  Printf.fprintf o "class %s < %s\n %a\nend\n" name super output_meths meths

and output_clss o = function
    [] -> ()
  | [c] -> Printf.fprintf o "%a" output_cls c
  | c::cs -> Printf.fprintf o "%a\n%a" output_cls c output_clss cs

and print_program ({prog_clss=clss; prog_main=main}:rube_prog) = match clss with
  | [] -> Printf.printf "%a\n" output_expr main
  | _ -> Printf.printf "%a\n%a\n" output_clss clss output_expr main

(*********************************************************************)
let x = ref 10;;
let new_reg () =
  x := !x + 1;
  !x


let nil = 
  let nilreg = new_reg () in
  let nilTable = new_reg () in
  let class_reg = new_reg () in
  let class_name = new_reg () in
  let extra = new_reg () in
  let instrs = [|I_mk_tab (`L_Reg nilreg);
                I_mk_tab (`L_Reg nilTable);
                I_const (`L_Reg extra, `L_Str "#vtable");
                I_const (`L_Reg class_reg, `L_Str "to_s");
                I_const (`L_Reg class_name, `L_Id "Object_to_s");
                I_wr_tab(`L_Reg nilTable, `L_Reg class_reg, `L_Reg class_name);
                I_const (`L_Reg class_reg, `L_Str "print");
                I_const (`L_Reg class_name, `L_Id "Object_print");
                I_wr_tab(`L_Reg nilTable, `L_Reg class_reg, `L_Reg class_name);
                I_const (`L_Reg class_reg, `L_Str "equal?");
                I_const (`L_Reg class_name, `L_Id "Object_equal");
                I_wr_tab(`L_Reg nilTable, `L_Reg class_reg, `L_Reg class_name);
                I_wr_tab (`L_Reg nilreg, `L_Reg extra, `L_Reg nilTable);|] in
  (nilreg, instrs)


let integer classtable n =
  let table = new_reg () in
  let obj = new_reg () in
  let vtab = new_reg () in
  let vt = Hashtbl.find classtable "Integer" in
  let init = [|I_mk_tab(`L_Reg obj);
               I_mk_tab(`L_Reg table);
               I_const(`L_Reg vtab, `L_Str "#vtable")|] in
  let r1 = new_reg () in
  let r2 = new_reg () in
  let f short_name full_name a =
      Array.append a [|I_const (`L_Reg r1, `L_Str (short_name));
      I_const (`L_Reg r2, `L_Id (full_name));
      I_wr_tab(`L_Reg table, `L_Reg r1, `L_Reg r2)|]
  in let instrs = Hashtbl.fold f vt init in
  let class_reg = new_reg () in
  let class_name = new_reg () in
  let endinstrs = [|I_const (`L_Reg class_name, `L_Str "Integer");
                    I_const (`L_Reg class_reg, `L_Str "#class");
                    I_wr_tab(`L_Reg obj, `L_Reg class_reg, `L_Reg class_name);
                    I_const (`L_Reg class_name, `L_Str "#contents");
                    I_const (`L_Reg class_reg, `L_Int n);
                    I_wr_tab (`L_Reg obj, `L_Reg class_name, `L_Reg class_reg);
                    I_wr_tab(`L_Reg obj, `L_Reg vtab, `L_Reg table)|] in
                   (obj,Array.append instrs endinstrs)

let stringgg classtable str =
  let r0 = new_reg () in
  let r = new_reg () in
  let vtab = new_reg () in
  let vt = Hashtbl.find classtable "String" in
  let init = [|I_mk_tab(`L_Reg r);
               I_mk_tab(`L_Reg r0);
               I_const(`L_Reg vtab, `L_Str "#vtable")|] in
  let r1 = new_reg () in
  let r2 = new_reg () in
  let f short_name full_name a =
      Array.append a [|I_const (`L_Reg r1, `L_Str (short_name));
      I_const (`L_Reg r2, `L_Id (full_name));
      I_wr_tab(`L_Reg r0, `L_Reg r1, `L_Reg r2)|]
  in let instrs = Hashtbl.fold f vt init in
  let class_reg = new_reg () in
  let class_name = new_reg () in
  let endinstrs = [|I_const (`L_Reg class_name, `L_Str "String");
                    I_const (`L_Reg class_reg, `L_Str "#class");
                    I_wr_tab(`L_Reg r, `L_Reg class_reg, `L_Reg class_name);
                    I_const (`L_Reg class_name, `L_Str "#contents");
                    I_const (`L_Reg class_reg, `L_Str str);
                    I_wr_tab (`L_Reg r, `L_Reg class_name, `L_Reg class_reg);
                    I_wr_tab(`L_Reg r, `L_Reg vtab, `L_Reg r0)|] in
                   (r,Array.append instrs endinstrs)
let new_map classtable =
  let r0 = new_reg () in
  let r = new_reg () in
  let vtab = new_reg () in
  let vt = Hashtbl.find classtable "Map" in
  let init = [|I_mk_tab(`L_Reg r);
               I_mk_tab(`L_Reg r0);
               I_const(`L_Reg vtab, `L_Str "#vtable")|] in
  let r1 = new_reg () in
  let r2 = new_reg () in
  let f short_name full_name a =
      Array.append a [|I_const (`L_Reg r1, `L_Str (short_name));
      I_const (`L_Reg r2, `L_Id (full_name));
      I_wr_tab(`L_Reg r0, `L_Reg r1, `L_Reg r2)|]
  in let instrs = Hashtbl.fold f vt init in
  let class_reg = new_reg () in
  let class_name = new_reg () in
  let endinstrs = [|I_const (`L_Reg class_name, `L_Str "Map");
                    I_const (`L_Reg class_reg, `L_Str "#class");
                    I_wr_tab(`L_Reg r, `L_Reg class_reg, `L_Reg class_name);
                    I_const (`L_Reg class_name, `L_Str "#contents");
                    I_mk_tab(`L_Reg class_reg);
                    I_wr_tab (`L_Reg r, `L_Reg class_name, `L_Reg class_reg);
                    I_wr_tab(`L_Reg r, `L_Reg vtab, `L_Reg r0)|] in
                   (r,Array.append instrs endinstrs)

let new_obj classtable clsType = 
  begin try
  let r0 = new_reg () in
  let r = new_reg () in
  let vtab = new_reg () in
  let vt = Hashtbl.find classtable clsType in
  let init = [|I_mk_tab(`L_Reg r);
               I_mk_tab(`L_Reg r0);
               I_const(`L_Reg vtab, `L_Str "#vtable")|] in
  let r1 = new_reg () in
  let r2 = new_reg () in
  let f short_name full_name a =
         Array.append a [|I_const (`L_Reg r1, `L_Str (short_name));
                          I_const (`L_Reg r2, `L_Id (full_name));
                          I_wr_tab(`L_Reg r0, `L_Reg r1, `L_Reg r2)|]
  in let instrs = Hashtbl.fold f vt init in
  let class_reg = new_reg () in
  let class_name = new_reg () in
  let endinstrs = [|I_const (`L_Reg class_name, `L_Str clsType);
                    I_const (`L_Reg class_reg, `L_Str "#class");
                    I_wr_tab(`L_Reg r, `L_Reg class_reg, `L_Reg class_name);
                    I_wr_tab(`L_Reg r, `L_Reg vtab, `L_Reg r0)|] in
                   (r,Array.append instrs endinstrs)
  with
  _ -> raise NoSuchClass end

let compile_prog ({prog_clss=classlist;prog_main=ex}:rube_prog):prog =
  (* change this! *)
  
  let classtable = Hashtbl.create 10 in
  let allinstrs = Hashtbl.create 50 in 
  let objectVtable = Hashtbl.create 3 in
  Hashtbl.add objectVtable "equal?" "Object_equal";
  Hashtbl.add objectVtable "to_s" "Object_to_s";
  Hashtbl.add objectVtable "print" "Object_print";
  Hashtbl.add classtable "Object" objectVtable;
  let stringVtable = Hashtbl.create 5 in
  Hashtbl.add stringVtable "+" "String_plus";
  Hashtbl.add stringVtable "length" "String_length";
  Hashtbl.add stringVtable "equal?" "String_equal";
  Hashtbl.add stringVtable "to_s" "String_to_s";
  Hashtbl.add stringVtable "print" "String_print";
  Hashtbl.add classtable "String" stringVtable;
  let integerVtable = Hashtbl.create 7 in
  Hashtbl.add integerVtable "+" "Integer_plus";
  Hashtbl.add integerVtable "-" "Integer_minus";
  Hashtbl.add integerVtable "*" "Integer_times";
  Hashtbl.add integerVtable "/" "Integer_divide";
  Hashtbl.add integerVtable "equal?" "Integer_equal";
  Hashtbl.add integerVtable "to_s" "Integer_to_s";
  Hashtbl.add integerVtable "print" "Integer_print";
  Hashtbl.add classtable "Integer" integerVtable;
  let mapVtable = Hashtbl.create 4 in
  Hashtbl.add mapVtable "find" "Map_find";
  Hashtbl.add mapVtable "insert" "Map_insert";
  Hashtbl.add mapVtable "has" "Map_has";
  Hashtbl.add mapVtable "iter" "Map_iter";
  Hashtbl.add classtable "Map" mapVtable; 
  let rec generateVtable {cls_name=n;cls_super=super;cls_meths=meths} =
    let vtable = begin try Hashtbl.copy (Hashtbl.find classtable super)
    with _-> 
          let f ({cls_name=cn;cls_super=s;cls_meths=m}:cls) =
            if cn = super then true else false
          in
          generateVtable (List.find f classlist);
          Hashtbl.copy (Hashtbl.find classtable super)
          end 
    in
    let rec methIterator lst =
      match lst with
      |h::t -> begin match h with {meth_name=mn;meth_args=args;meth_body=bod} ->
                Hashtbl.replace vtable mn (n^"_"^mn);methIterator t end
      |[]->() 
    in methIterator meths; Hashtbl.replace classtable n vtable;()
  in 
  let rec classIterator lst =
    match lst with
    |h::t-> generateVtable h;classIterator t
    |[]->()
  in classIterator classlist;
  (*move eval_method up here so I can instantiate self and args and put eval expr inside eval method*)
  (*let eval_method {meth_name=mn;meth_args=args;meth_body=bod} =*)
  let rec eval_expr e objectMap = 
  (*output_expr stdout e;
  Printf.fprintf stdout "\n";
  let inn = Hashtbl.find objectMap "self" in
  Printf.fprintf stdout "%d\n" inn;
  *)
      begin  
      match e with
      | EInt n -> let (x,y) = integer classtable n in (x,y,objectMap)
                  (*(reg,[|I_const (`L_Reg reg, `L_Int n)|])*)
      | ENil -> let(x,y) = nil in (x,y,objectMap)
      | ESelf -> (0,[||], objectMap)
      | EString str -> let (x,y) = stringgg classtable str in (x,y,objectMap)
      | ELocWr (identifier, exp) -> 
          let curreg = (begin try Hashtbl.find objectMap identifier
                        with _ -> new_reg () end) in
          Hashtbl.replace objectMap identifier curreg;
          let (reg,code,_)=eval_expr exp objectMap in 
          let writeinstrs = [|I_mov (`L_Reg curreg, `L_Reg reg)|] in
          (curreg, (Array.append code writeinstrs), objectMap)
      | ELocRd str-> begin try
                        let reg = Hashtbl.find objectMap str in
                        (reg, [||], objectMap)
                      with _-> let reg = new_reg () in
                      let failinstrs = [|I_const(`L_Reg reg, `L_Str "Undefined Variable");
                                          I_halt(`L_Reg reg)|] in
                      (reg, failinstrs, objectMap) end
      | EFldRd str-> let self = Hashtbl.find objectMap "self" in
                      let return = new_reg () in
                      let fld = new_reg () in
                      let exists = new_reg () in
                      let instrs = [| I_const(`L_Reg fld, `L_Str str);
                                      I_has_tab(`L_Reg exists, `L_Reg self, `L_Reg fld);
                                      I_if_zero(`L_Reg exists, 3);
                                      I_rd_tab(`L_Reg exists, `L_Reg self, `L_Reg fld);
                                      I_mov(`L_Reg return, `L_Reg exists);
                                      I_jmp 14|] in
                      let (nilObj, nilCode) = nil in
                      let finals = [|I_mov(`L_Reg return, `L_Reg nilObj)|] in
                      (return, (Array.append instrs (Array.append nilCode finals)), objectMap)
      | EFldWr (str,e1)-> let (fld, fldCode, _) = eval_expr e1 objectMap in
                          let self = Hashtbl.find objectMap "self" in
                          let name = new_reg () in
                          let lastinstr = [|I_const(`L_Reg name, `L_Str str);
                                            I_wr_tab(`L_Reg self, `L_Reg name, `L_Reg fld)|] in
                          (fld, (Array.append fldCode lastinstr), objectMap)
      | EIf (e1,e2,e3)->
                      let (guardVal, guardCode, _) = eval_expr e1 objectMap in
                      let (thenVal, thenCode, _) = eval_expr e2 objectMap in
                      let (elseVal, elseCode, _) = eval_expr e3 objectMap in
                      let offset1 = (Array.length thenCode + 2)in
                      let offset2 = (Array.length elseCode + 1)in
                      let returnVal = new_reg () in
                      let classtype = new_reg () in
                      let nonNil = new_reg () in
                      let ifPart1 = [|I_const(`L_Reg classtype, `L_Str "#class");
                                      I_has_tab(`L_Reg nonNil, `L_Reg guardVal, `L_Reg classtype);
                                      I_if_zero(`L_Reg nonNil, offset1)|] in
                      let guardPlusIf = Array.append (Array.append guardCode ifPart1) thenCode in
                      let half = Array.append guardPlusIf [|I_mov(`L_Reg returnVal, `L_Reg thenVal);
                                                            I_jmp offset2|] in
                      let secondhalf = Array.append elseCode [|I_mov (`L_Reg returnVal, `L_Reg elseVal)|] in
                      (returnVal, (Array.append half secondhalf), objectMap)

      | EWhile (e1,e2)->
          let (nilReg, nilCode) = nil in
          let (guardVal, guardCode, _) = eval_expr e1 objectMap in
          let (bodyVal, bodyCode, _) = eval_expr e2 objectMap in
          let offset1 = (Array.length bodyCode +1) in
          let offset2 = ((Array.length bodyCode) + (Array.length guardCode) + 3) in
          let nonNil = new_reg () in
          let classtype = new_reg () in
          let ifPart1 = [|I_const(`L_Reg classtype, `L_Str "#class");
                          I_has_tab(`L_Reg nonNil, `L_Reg guardVal, `L_Reg classtype);
                          I_if_zero(`L_Reg nonNil, offset1)|] in
          let guardPlusIf = Array.append (Array.append guardCode ifPart1) bodyCode in
          let total = Array.append guardPlusIf [|I_jmp (-offset2)|] in
          (nilReg, total, objectMap) 
      | ESeq (exp1, exp2) ->
          let (firstreg, firsteval,_) = eval_expr exp1 objectMap in
          let (secondreg, secondeval,_) = eval_expr exp2 objectMap in
          let combinedinstrs = Array.append firsteval secondeval in
          (secondreg, combinedinstrs, objectMap)
      | ENew clsType -> begin if(clsType = "Bot") then 
                        let r = new_reg () in
                        (r,[|I_const(`L_Reg r, `L_Str "Cannot instantiate Bot");
                          I_halt(`L_Reg r)|], objectMap)
                      else if(clsType = "String") then
                        let (a,b) = stringgg classtable "" in (a,b,objectMap) 
                      else if(clsType = "Integer") then
                        let (c,d) = integer classtable 0 in (c,d,objectMap)
                      else if(clsType = "Map") then
                        let (e,f) = new_map classtable in (e,f, objectMap)
                      else
                        let (x,y) = new_obj classtable clsType in (x,y,objectMap)
                      end
      | EInstanceOf (e1,str)->let (expReg, expCode, _ ) = eval_expr e1 objectMap in
                              let (nilReg, nilCode) = nil in
                              let (intReg, intCode) = integer classtable 1 in
                              let classname = new_reg () in
                              let valueee = new_reg () in
                              let nonNil = new_reg () in
                              let returnReg = new_reg () in
                              let constant = new_reg () in
                              let n = new_reg () in
                              let instructions = 
                              [|I_const(`L_Reg constant, `L_Str str);
                              I_const(`L_Reg classname, `L_Str "#class");
                                I_has_tab(`L_Reg nonNil, `L_Reg expReg, `L_Reg classname);
                                I_if_zero(`L_Reg nonNil, 5);
                                I_rd_tab(`L_Reg valueee, `L_Reg expReg, `L_Reg classname);
                                I_eq(`L_Reg returnReg, `L_Reg valueee, `L_Reg constant);
                                I_if_zero(`L_Reg returnReg, 2);
                                I_mov(`L_Reg returnReg, `L_Reg intReg);
                                I_jmp 6;
                                I_mov(`L_Reg returnReg, `L_Reg nilReg);
                                I_const (`L_Reg n, `L_Str "Bot");
                                I_jmp 3;
                                I_eq(`L_Reg returnReg, `L_Reg n, `L_Reg constant);
                                I_if_zero(`L_Reg returnReg, (-5));
                                I_jmp (-7);
                                I_ret(`L_Reg returnReg)
                              |] in
      let total = Array.append nilCode (Array.append intCode (Array.append expCode instructions)) in
      (returnReg, total, objectMap) 
      | EInvoke (exp,str,explist)-> 
        let (obj, objCode, _) = eval_expr exp objectMap in
        let rec eval_exprlist lst instrs registers objmap =
          match lst with
          |h::t-> let (x,y,omap) = eval_expr h objmap in
                  let arr = Array.append instrs y in
                  let regs = registers@[x] in eval_exprlist t arr regs omap
          |[]-> (registers, instrs, objmap)
        in let (regs, eval_instrs, newObjectMap) = eval_exprlist explist [||] [] objectMap in
        let offset = List.length regs in
        let reg1 = new_reg () in
        let vtab = new_reg () in
        let reg2 = new_reg () in
        let reg3 = new_reg () in
        let findMethod = [|I_const(`L_Reg reg1, `L_Str "#vtable");
                           I_rd_tab(`L_Reg vtab, `L_Reg obj, `L_Reg reg1);
                           I_const(`L_Reg reg2, `L_Str str);
                           I_has_tab(`L_Reg reg3, `L_Reg vtab, `L_Reg reg2);
                           I_if_zero(`L_Reg reg3, offset+4)|] in
        let codePart1 = Array.append objCode (Array.append eval_instrs findMethod) in
        (*let self_reg = obj in*)
        let generateMoveInstrs a h =
            let z = new_reg() in
            Array.append a [|I_mov(`L_Reg z, `L_Reg h)|]
        in 
        let new_self_reg = new_reg () in 
        let mov_instrs 
            = List.fold_left generateMoveInstrs [|I_mov(`L_Reg new_self_reg, `L_Reg obj)|] regs in
        let realname = new_reg () in
        let endinstrs = [|I_rd_tab(`L_Reg realname, `L_Reg vtab, `L_Reg reg2);
                          I_call(`L_Reg realname, reg3+1, (reg3+Array.length mov_instrs));
                          I_jmp 2;
                          I_const(`L_Reg reg3, `L_Str "No Such Method");
                          I_halt (`L_Reg reg3)|] in
        let codePart2 = Array.append mov_instrs endinstrs in
        let total = Array.append codePart1 codePart2 in
        (reg3+1, total, newObjectMap)
    end
  in
  (*generate code*)
  let generateClassMethods {cls_name=cls_nm;cls_super=cls_supr;cls_meths=cls_mths} =
    (*evaluate methods into code*)
    let eval_method {meth_name=mn;meth_args=args;meth_body=body} = 
      let objectMap = Hashtbl.create 10 in
      Hashtbl.add objectMap "self" 0;
      let map_parameters a elt =
        Hashtbl.add objectMap elt (a+1);()
      in 
      List.iteri map_parameters args;
      let (reg, code, _) = eval_expr body objectMap in
      let codePlusRet = Array.append code [|I_ret(`L_Reg reg)|] in
      Hashtbl.add allinstrs (cls_nm^"_"^mn) codePlusRet;()
    in
    let rec generateMethodCode lst = match lst with
    |h::t -> eval_method h;
            generateMethodCode t
    |[]->()
    in generateMethodCode cls_mths
  in
  let rec classGenerator lst = 
    match lst with
    |h::t-> generateClassMethods h; classGenerator t
    |[]->()
  in classGenerator classlist;
  let omap = Hashtbl.create 10 in
  Hashtbl.add omap "self" 0;
  let (obj, mic) = new_obj classtable "Object" in
  let mainInitCode = Array.append mic [|I_mov(`L_Reg 0, `L_Reg obj)|] in
  let (reg, maincode, _) = (eval_expr ex omap) in
  let vtable = new_reg () in
  let table = new_reg () in
  let contents = new_reg () in
  let value = new_reg () in
  let ret = [|I_const(`L_Reg vtable, `L_Str "#vtable");
              I_rd_tab(`L_Reg table, `L_Reg reg, `L_Reg vtable);
              I_const(`L_Reg vtable, `L_Str "to_s");
              I_rd_tab(`L_Reg vtable, `L_Reg table, `L_Reg vtable);
              I_call(`L_Reg vtable, reg, reg);
              I_const(`L_Reg contents, `L_Str "#contents");
              I_rd_tab(`L_Reg value, `L_Reg reg, `L_Reg contents);
              I_ret(`L_Reg value)|] in
  let mainCodeWReturn = Array.append maincode ret in
  let allMainCode = Array.append mainInitCode mainCodeWReturn in
  Hashtbl.add allinstrs "main" allMainCode;
  let instructions = [|I_const(`L_Reg 2, `L_Str "#contents");
                       I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
                       I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
                       I_add(`L_Reg 5, `L_Reg 3, `L_Reg 4);
                       I_const(`L_Reg 8, `L_Str "#vtable");
                       I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
                       I_mk_tab(`L_Reg 7);
                       I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 5);
                       I_const(`L_Reg 2, `L_Str "#class");
                       I_const(`L_Reg 3, `L_Str "Integer");
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_ret(`L_Reg 7)|] in
  Hashtbl.add allinstrs "Integer_plus" instructions;
  let instructions = [|I_const(`L_Reg 2, `L_Str "#contents");
                       I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
                       I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
                       I_sub(`L_Reg 5, `L_Reg 3, `L_Reg 4);
                       I_const(`L_Reg 8, `L_Str "#vtable");
                       I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
                       I_mk_tab(`L_Reg 7);
                       I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 5);
                       I_const(`L_Reg 2, `L_Str "#class");
                       I_const(`L_Reg 3, `L_Str "Integer");
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_ret(`L_Reg 7)|] in
  Hashtbl.add allinstrs "Integer_minus" instructions;
  let instructions = [|I_const(`L_Reg 2, `L_Str "#contents");
                       I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
                       I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
                       I_mul(`L_Reg 5, `L_Reg 3, `L_Reg 4);
                       I_const(`L_Reg 8, `L_Str "#vtable");
                       I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
                       I_mk_tab(`L_Reg 7);
                       I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 5);
                       I_const(`L_Reg 2, `L_Str "#class");
                       I_const(`L_Reg 3, `L_Str "Integer");
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_ret(`L_Reg 7)|] in
  Hashtbl.add allinstrs "Integer_times" instructions;
  let instructions = [|I_const(`L_Reg 2, `L_Str "#contents");
                       I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
                       I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
                       I_div(`L_Reg 5, `L_Reg 3, `L_Reg 4);
                       I_const(`L_Reg 8, `L_Str "#vtable");
                       I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
                       I_mk_tab(`L_Reg 7);
                       I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 5);
                       I_const(`L_Reg 2, `L_Str "#class");
                       I_const(`L_Reg 3, `L_Str "Integer");
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_ret(`L_Reg 7)|] in
  Hashtbl.add allinstrs "Integer_div" instructions;
  let instructions = [|I_const(`L_Reg 2, `L_Str "#contents");
                       I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
                       I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
                       I_eq(`L_Reg 5, `L_Reg 3, `L_Reg 4);
                       I_if_zero(`L_Reg 5, 11);
                       I_const(`L_Reg 8, `L_Str "#vtable");
                       I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
                       I_mk_tab(`L_Reg 7);
                       I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
                       I_const(`L_Reg 3, `L_Int 1);
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_const(`L_Reg 2, `L_Str "#class");
                       I_const(`L_Reg 3, `L_Str "Integer");
                       I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
                       I_mov(`L_Reg 11, `L_Reg 7);
                       I_jmp 14|] in 
  let (nilreg, nilInstrs) = nil in
  let end_method = Array.append instructions nilInstrs in
  let total = Array.append end_method [|I_mov(`L_Reg 11, `L_Reg nilreg);I_ret(`L_Reg 11)|] in
  Hashtbl.add allinstrs "Integer_equal" total;
  (*let (basicObj, initCode) = new_obj classtable "String" in*)
  let (stringObj, stringObjCode) = new_obj classtable "String" in
  let instructions = [|I_const(`L_Reg 1, `L_Str "#contents");
                       I_rd_tab(`L_Reg 2, `L_Reg 0, `L_Reg 1);
                       I_const(`L_Reg 3, `L_Id "to_s");
                       I_call(`L_Reg 3, 2, 2)|] in
  let stringCode = Array.append stringObjCode 
        [|I_wr_tab(`L_Reg stringObj, `L_Reg 1, `L_Reg 2);
        I_ret(`L_Reg stringObj)|] in
  Hashtbl.add allinstrs "Integer_to_s" (Array.append instructions stringCode);                     
  
  let instructions = 
  [|I_const(`L_Reg 2, `L_Str "#contents");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
    I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
    I_const(`L_Reg 5, `L_Id "concat");
    I_call(`L_Reg 5, 3, 4);
    I_const(`L_Reg 8, `L_Str "#vtable");
    I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
    I_mk_tab(`L_Reg 7);
    I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
    I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
    I_const(`L_Reg 2, `L_Str "#class");
    I_const(`L_Reg 3, `L_Str "String");
    I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
    I_ret(`L_Reg 7)|]in
  Hashtbl.add allinstrs "String_plus" instructions; 
  let instructions = 
  [|I_const(`L_Reg 2, `L_Str "#contents");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
    I_rd_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
    I_eq(`L_Reg 5, `L_Reg 3, `L_Reg 4);
    I_if_zero(`L_Reg 5, 11);
    I_const(`L_Reg 8, `L_Str "#vtable");
    I_rd_tab(`L_Reg 6, `L_Reg 0, `L_Reg 8);
    I_mk_tab(`L_Reg 7);
    I_wr_tab(`L_Reg 7, `L_Reg 8, `L_Reg 6);
    I_const(`L_Reg 3, `L_Int 1);
    I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
    I_const(`L_Reg 2, `L_Str "#class");
    I_const(`L_Reg 3, `L_Str "String");
    I_wr_tab(`L_Reg 7, `L_Reg 2, `L_Reg 3);
    I_mov(`L_Reg 11, `L_Reg 7);
    I_jmp 14|] in 
  let (nilreg, nilInstrs) = nil in
  let end_method = Array.append instructions nilInstrs in
  let total = Array.append end_method [|I_mov(`L_Reg 11, `L_Reg nilreg);I_ret(`L_Reg 11)|] in
  Hashtbl.add allinstrs "String_equal" total;                    
  let instructions = 
  [|I_const(`L_Reg 1, `L_Str "#contents");
  I_rd_tab(`L_Reg 2, `L_Reg 0, `L_Reg 1);
  I_const(`L_Reg 3, `L_Id "length");
  I_call(`L_Reg 3, 2, 2)|] in
  let (length, intCreator) = new_obj classtable "Integer" in
  let final = [|I_wr_tab(`L_Reg length, `L_Reg 1, `L_Reg 2);
                I_ret (`L_Reg length)|]
  in Hashtbl.add allinstrs "String_length" (Array.append instructions (Array.append intCreator final));
  let instructions = 
  [|I_ret(`L_Reg 0)|] in
  Hashtbl.add allinstrs "String_to_s" instructions;

  let (intReturn, intCode) = integer classtable 1 in
  let (nilReg, nilCode) = nil in
  let vals = Array.append nilCode intCode in
  let compareInstrs = [|I_eq(`L_Reg 2, `L_Reg 0, `L_Reg 1);
                        I_if_zero(`L_Reg 2, 2);
                        I_mov(`L_Reg 3, `L_Reg intReturn);
                        I_jmp 1;
                        I_mov(`L_Reg 3, `L_Reg nilReg);
                        I_ret(`L_Reg 3)|] in
  Hashtbl.add allinstrs "Object_equal" (Array.append vals compareInstrs);

  let (stringObj, stringObjCode) = stringgg classtable "nil" in
  let instructions = [|I_ret(`L_Reg stringObj)|] in
  Hashtbl.add allinstrs "Object_to_s" (Array.append stringObjCode instructions);

  let instructions = 
  [|I_const(`L_Reg 1, `L_Str "#contents");
    I_const(`L_Reg 2, `L_Id "print_int");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 1);
    I_call(`L_Reg 2, 3, 3)|] in
    let total = Array.append nilCode (Array.append instructions [|I_ret (`L_Reg nilreg)|]) in
  Hashtbl.add allinstrs "Integer_print" total;

  let instructions = 
  [|I_const(`L_Reg 1, `L_Str "#contents");
    I_const(`L_Reg 2, `L_Id "print_string");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 1);
    I_call(`L_Reg 2, 3, 3)|] in
    let total = Array.append nilCode (Array.append instructions [|I_ret (`L_Reg nilreg)|]) in
  Hashtbl.add allinstrs "String_print" total;

  let instructions = 
  [|I_const(`L_Reg 1, `L_Str "#contents");
    I_const(`L_Reg 2, `L_Id "print_string");
    I_const(`L_Reg 3, `L_Str "nil");
    I_call(`L_Reg 2, 3, 3)|] in
    let total = Array.append nilCode (Array.append instructions [|I_ret (`L_Reg nilreg)|]) in
  Hashtbl.add allinstrs "Object_print" total;

  let (intReg, intCode) = integer classtable 1 in
  let (nilReg, nilCode) = nil in
  let returnReg = new_reg () in
  let instructions = 
  [|I_const (`L_Reg 2, `L_Str "#contents");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
    I_has_tab(`L_Reg 4, `L_Reg 3, `L_Reg 1);
    I_if_zero(`L_Reg 4, 2)
  |] in
  let beginCode = Array.append nilCode (Array.append intCode instructions) in
  let endCode = 
  [|I_mov(`L_Reg returnReg, `L_Reg intReg);
    I_jmp 1;
    I_mov(`L_Reg returnReg, `L_Reg intReg);
    I_ret(`L_Reg returnReg);
  |] in 
  Hashtbl.add allinstrs "Map_has" (Array.append beginCode endCode);

  let instructions = 
  [|I_const(`L_Reg 2, `L_Str "#contents");
    I_rd_tab(`L_Reg 3, `L_Reg 0, `L_Reg 2);
    I_rd_tab(`L_Reg 4, `L_Reg 3, `L_Reg 2);
    I_ret (`L_Reg 4)|] in
    Hashtbl.add allinstrs "Map_find" instructions;

  let(nilReg, nilCode) = nil in
  let instructions =
  [|I_const(`L_Reg 3, `L_Str "#contents");
    I_rd_tab(`L_Reg 4, `L_Reg 0, `L_Reg 3);
    I_wr_tab(`L_Reg 4, `L_Reg 1, `L_Reg 2);
    I_ret(`L_Reg nilReg)|] in
  Hashtbl.add allinstrs "Map_insert" (Array.append nilCode instructions);


  allinstrs

(*********************************************************************)

let parse_file name =
  let chan = open_in name in
  let lexbuf = Lexing.from_channel chan in
  let (p:rube_prog) = Parser.main Lexer.token lexbuf in
    close_in chan;
    p

let main () =
  let p = parse_file Sys.argv.(1) in
  let (p':Instr.prog) = compile_prog p in
  let out_chan = open_out "rubec.out" in
    (*disassemble out_chan p'*)

;;

main ()